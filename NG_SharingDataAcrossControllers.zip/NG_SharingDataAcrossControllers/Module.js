﻿//1.
var app = angular.module('main', ['ngRoute']);
//2.
app.factory('fact', function () {
    return {
        data: {}
    }
});
//3.
app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
    $routeProvider.when("/list", {
        templateUrl: 'app/Views/List.html',
        controller: 'listctrl'
    });
    $routeProvider.when("/details", {
        templateUrl: 'app/Views/Details.html',
        controller: 'detailsctrl'
    });
    $routeProvider.otherwise("/");
}]);