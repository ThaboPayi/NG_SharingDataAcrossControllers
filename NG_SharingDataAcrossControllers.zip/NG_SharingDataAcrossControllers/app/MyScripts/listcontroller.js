﻿//1.
app.controller('listctrl', function ($scope, fact, $location) {

    $scope.Employees = [
        { EmpNo: 101, EmpName: 'MS', Salary: 23000 },
        { EmpNo: 102, EmpName: 'LS', Salary: 13000 },
        { EmpNo: 103, EmpName: 'TS', Salary: 3000 },
        { EmpNo: 104, EmpName: 'VB', Salary: 43000 },
        { EmpNo: 105, EmpName: 'PB', Salary: 33000 },
        { EmpNo: 106, EmpName: 'AB', Salary: 13000 }
    ];

    $scope.getSelected = function (emp) {
        fact.Data = emp;
        $location.path("/details");
    };
});