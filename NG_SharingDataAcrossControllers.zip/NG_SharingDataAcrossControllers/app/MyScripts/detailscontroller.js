﻿//1.
app.controller('detailsctrl', function ($scope, fact, $location) {

    $scope.Employee = {
        EmpNo: fact.Data.EmpNo,
        EmpName: fact.Data.EmpName,
        Salary: fact.Data.Salary
    };
    $scope.back = function () {
        $location.path("/");
    }
});